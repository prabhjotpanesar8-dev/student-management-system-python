STUDENT MANAGEMENT SYSTEM (DESKTOP) - MCA MINI PROJECT
=======================================================

Features
- Add, view, search, update and delete student records (CRUD)
- Store roll number, name, course, semester, phone, email and marks
- Validate required fields, semester (1-12), marks (0-100), and email format
- Prevent duplicate roll numbers
- Show total students and records matching a search

Technologies
- Python 3
- Tkinter / ttk GUI
- SQLite database

Setup
1. Install Python 3.10+ from https://www.python.org/downloads/
2. Extract this ZIP and open the folder.
3. Run the app:
   Windows:  py student_management.py
   macOS/Linux: python3 student_management.py
4. Tkinter and sqlite3 are included with most standard Python installations.
5. A file named students.db is created automatically in the current working directory.

No pip installation is normally required.
If Tkinter is missing on Linux, install your distribution's python3-tk package.

How to use
1. Fill all fields on the left.
2. Click Save Student.
3. Search by roll number, student name or course.
4. Select a row to load its details into the form.
5. Edit fields and click Update Selected, or click Delete Selected.
6. Click Clear Form to start a new entry.

Database table: students
- id: INTEGER PRIMARY KEY AUTOINCREMENT
- roll_no: TEXT UNIQUE NOT NULL
- name: TEXT NOT NULL
- course: TEXT NOT NULL
- semester: INTEGER NOT NULL
- phone: TEXT NOT NULL
- email: TEXT NOT NULL
- marks: REAL NOT NULL (0 to 100)

Sample test record
Roll number: MCA001
Full name: Simran Kaur
Course: MCA
Semester: 2
Phone: 9876543210
Email: simran@example.com
Marks: 86.5

Important
- This is an educational local project. Use fictional sample records in demonstrations.
- SQLite database is created automatically; do not delete students.db if you want to retain saved data.
