import sqlite3
import tkinter as tk
from tkinter import ttk, messagebox

DB_NAME = "students.db"


def connect_db():
    connection = sqlite3.connect(DB_NAME)
    connection.row_factory = sqlite3.Row
    return connection


def setup_database():
    with connect_db() as connection:
        connection.execute("""
            CREATE TABLE IF NOT EXISTS students (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                roll_no TEXT NOT NULL UNIQUE,
                name TEXT NOT NULL,
                course TEXT NOT NULL,
                semester INTEGER NOT NULL,
                phone TEXT NOT NULL,
                email TEXT NOT NULL,
                marks REAL NOT NULL CHECK(marks >= 0 AND marks <= 100)
            )
        """)
        connection.commit()


class StudentManagementApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Student Management System")
        self.root.geometry("1120x700")
        self.root.minsize(900, 600)
        self.root.configure(bg="#f4f6fb")
        self.selected_id = None

        self.style = ttk.Style()
        try:
            self.style.theme_use("clam")
        except tk.TclError:
            pass
        self.style.configure("Treeview", rowheight=30, font=("Segoe UI", 10),
                             background="white", fieldbackground="white")
        self.style.configure("Treeview.Heading", font=("Segoe UI", 10, "bold"),
                             background="#e9eafe", foreground="#28264d")
        self.style.map("Treeview", background=[("selected", "#dcd9ff")],
                       foreground=[("selected", "#202044")])

        self.build_ui()
        self.load_students()

    def build_ui(self):
        header = tk.Frame(self.root, bg="#5146c8", height=90)
        header.pack(fill="x")
        header.pack_propagate(False)
        tk.Label(header, text="🎓  Student Management System",
                 font=("Segoe UI", 22, "bold"), bg="#5146c8",
                 fg="white").pack(anchor="w", padx=28, pady=(15, 0))
        tk.Label(header, text="Add, search, update and manage student marks",
                 font=("Segoe UI", 10), bg="#5146c8",
                 fg="#e6e4ff").pack(anchor="w", padx=31, pady=(2, 10))

        body = tk.Frame(self.root, bg="#f4f6fb")
        body.pack(fill="both", expand=True, padx=22, pady=18)

        self.stats_label = tk.Label(body, text="Total students: 0",
                                    font=("Segoe UI", 12, "bold"),
                                    bg="#f4f6fb", fg="#5146c8")
        self.stats_label.pack(anchor="w", pady=(0, 12))

        content = tk.Frame(body, bg="#f4f6fb")
        content.pack(fill="both", expand=True)

        form = tk.Frame(content, bg="white", highlightbackground="#e3e5f0",
                        highlightthickness=1, padx=18, pady=16)
        form.pack(side="left", fill="y", padx=(0, 18))
        form.configure(width=310)
        form.pack_propagate(False)

        tk.Label(form, text="Student Details", font=("Segoe UI", 15, "bold"),
                 bg="white", fg="#242442").pack(anchor="w", pady=(0, 14))

        self.vars = {
            "roll_no": tk.StringVar(),
            "name": tk.StringVar(),
            "course": tk.StringVar(value="MCA"),
            "semester": tk.StringVar(value="1"),
            "phone": tk.StringVar(),
            "email": tk.StringVar(),
            "marks": tk.StringVar(value="0")
        }

        self.add_field(form, "Roll number *", "roll_no")
        self.add_field(form, "Full name *", "name")
        self.add_field(form, "Course *", "course")
        self.add_field(form, "Semester (1–12) *", "semester")
        self.add_field(form, "Phone *", "phone")
        self.add_field(form, "Email *", "email")
        self.add_field(form, "Marks (0–100) *", "marks")

        buttons = tk.Frame(form, bg="white")
        buttons.pack(fill="x", pady=(15, 4))
        self.make_button(buttons, "Save Student", self.add_student,
                         "#5146c8").pack(fill="x", pady=3)
        self.make_button(buttons, "Update Selected", self.update_student,
                         "#16865d").pack(fill="x", pady=3)
        self.make_button(buttons, "Delete Selected", self.delete_student,
                         "#c74455").pack(fill="x", pady=3)
        self.make_button(buttons, "Clear Form", self.clear_form,
                         "#667085").pack(fill="x", pady=3)

        records = tk.Frame(content, bg="white", highlightbackground="#e3e5f0",
                           highlightthickness=1, padx=14, pady=14)
        records.pack(side="left", fill="both", expand=True)

        search_bar = tk.Frame(records, bg="white")
        search_bar.pack(fill="x", pady=(0, 12))
        tk.Label(search_bar, text="Student Records", font=("Segoe UI", 15, "bold"),
                 bg="white", fg="#242442").pack(anchor="w", pady=(0, 10))
        search_row = tk.Frame(search_bar, bg="white")
        search_row.pack(fill="x")
        self.search_var = tk.StringVar()
        search_entry = ttk.Entry(search_row, textvariable=self.search_var)
        search_entry.pack(side="left", fill="x", expand=True, ipady=5)
        search_entry.bind("<Return>", lambda event: self.search_students())
        self.make_button(search_row, "Search", self.search_students,
                         "#5146c8").pack(side="left", padx=(7, 4))
        self.make_button(search_row, "Show All", self.load_students,
                         "#667085").pack(side="left")

        columns = ("roll_no", "name", "course", "semester", "marks", "phone")
        self.tree = ttk.Treeview(records, columns=columns, show="headings",
                                 selectmode="browse")
        headings = {
            "roll_no": "Roll No.", "name": "Student Name", "course": "Course",
            "semester": "Semester", "marks": "Marks", "phone": "Phone"
        }
        widths = {"roll_no": 90, "name": 150, "course": 80,
                  "semester": 75, "marks": 65, "phone": 115}
        for col in columns:
            self.tree.heading(col, text=headings[col])
            self.tree.column(col, width=widths[col], minwidth=55, anchor="w")
        self.tree.pack(fill="both", expand=True)
        self.tree.bind("<<TreeviewSelect>>", self.on_select)

        tk.Label(body, text="Tip: Select a row to edit or delete a student.",
                 font=("Segoe UI", 9), bg="#f4f6fb", fg="#7b8095").pack(
                     anchor="w", pady=(10, 0))

    def add_field(self, parent, label, key):
        tk.Label(parent, text=label, font=("Segoe UI", 9, "bold"),
                 bg="white", fg="#4b4d64").pack(anchor="w", pady=(0, 4))
        if key == "course":
            widget = ttk.Combobox(parent, textvariable=self.vars[key],
                                  values=["MCA", "BCA", "B.Tech", "MBA",
                                          "B.Sc", "M.Sc", "Other"])
        elif key == "semester":
            widget = ttk.Combobox(parent, textvariable=self.vars[key],
                                  values=[str(i) for i in range(1, 13)])
        else:
            widget = ttk.Entry(parent, textvariable=self.vars[key])
        widget.pack(fill="x", ipady=4, pady=(0, 8))

    @staticmethod
    def make_button(parent, text, command, color):
        return tk.Button(parent, text=text, command=command, bg=color,
                         fg="white", activebackground=color, activeforeground="white",
                         relief="flat", bd=0, cursor="hand2",
                         font=("Segoe UI", 9, "bold"), padx=10, pady=7)

    def get_form_data(self):
        data = {key: var.get().strip() for key, var in self.vars.items()}
        if not all(data.values()):
            messagebox.showwarning("Missing information",
                                   "Please fill in all fields.")
            return None
        try:
            semester = int(data["semester"])
            marks = float(data["marks"])
            if not 1 <= semester <= 12:
                raise ValueError("Semester must be between 1 and 12.")
            if not 0 <= marks <= 100:
                raise ValueError("Marks must be between 0 and 100.")
        except ValueError as error:
            messagebox.showerror("Invalid input", str(error) or
                                 "Semester must be an integer and marks must be numeric.")
            return None
        if "@" not in data["email"] or "." not in data["email"].split("@")[-1]:
            messagebox.showerror("Invalid email", "Enter a valid email address.")
            return None
        data["semester"] = semester
        data["marks"] = marks
        return data

    def add_student(self):
        data = self.get_form_data()
        if data is None:
            return
        try:
            with connect_db() as connection:
                connection.execute("""
                    INSERT INTO students
                    (roll_no, name, course, semester, phone, email, marks)
                    VALUES (?, ?, ?, ?, ?, ?, ?)
                """, (data["roll_no"], data["name"], data["course"],
                      data["semester"], data["phone"], data["email"], data["marks"]))
                connection.commit()
            messagebox.showinfo("Success", "Student added successfully.")
            self.clear_form()
            self.load_students()
        except sqlite3.IntegrityError:
            messagebox.showerror("Duplicate roll number",
                                 "This roll number already exists. Enter a unique roll number.")

    def update_student(self):
        if self.selected_id is None:
            messagebox.showwarning("Select a student",
                                   "Select a student record from the table first.")
            return
        data = self.get_form_data()
        if data is None:
            return
        try:
            with connect_db() as connection:
                connection.execute("""
                    UPDATE students
                    SET roll_no=?, name=?, course=?, semester=?, phone=?, email=?, marks=?
                    WHERE id=?
                """, (data["roll_no"], data["name"], data["course"],
                      data["semester"], data["phone"], data["email"],
                      data["marks"], self.selected_id))
                connection.commit()
            messagebox.showinfo("Success", "Student updated successfully.")
            self.clear_form()
            self.load_students()
        except sqlite3.IntegrityError:
            messagebox.showerror("Duplicate roll number",
                                 "Another student already uses this roll number.")

    def delete_student(self):
        if self.selected_id is None:
            messagebox.showwarning("Select a student",
                                   "Select a student record from the table first.")
            return
        if not messagebox.askyesno("Confirm deletion",
                                   "Are you sure you want to delete this student?"):
            return
        with connect_db() as connection:
            connection.execute("DELETE FROM students WHERE id=?",
                               (self.selected_id,))
            connection.commit()
        messagebox.showinfo("Deleted", "Student record deleted.")
        self.clear_form()
        self.load_students()

    def load_students(self):
        self.search_var.set("")
        self.refresh_table()

    def search_students(self):
        self.refresh_table(self.search_var.get().strip())

    def refresh_table(self, search=""):
        for item in self.tree.get_children():
            self.tree.delete(item)
        with connect_db() as connection:
            if search:
                pattern = f"%{search}%"
                rows = connection.execute("""
                    SELECT * FROM students
                    WHERE roll_no LIKE ? OR name LIKE ? OR course LIKE ?
                    ORDER BY id DESC
                """, (pattern, pattern, pattern)).fetchall()
            else:
                rows = connection.execute(
                    "SELECT * FROM students ORDER BY id DESC"
                ).fetchall()
            total = connection.execute(
                "SELECT COUNT(*) FROM students"
            ).fetchone()[0]
        for row in rows:
            self.tree.insert("", "end", iid=str(row["id"]), values=(
                row["roll_no"], row["name"], row["course"], row["semester"],
                f'{row["marks"]:g}', row["phone"]
            ))
        self.stats_label.config(text=f"Total students: {total}     |     Records shown: {len(rows)}")

    def on_select(self, _event=None):
        selection = self.tree.selection()
        if not selection:
            return
        self.selected_id = int(selection[0])
        with connect_db() as connection:
            row = connection.execute(
                "SELECT * FROM students WHERE id=?", (self.selected_id,)
            ).fetchone()
        if row:
            for key in self.vars:
                self.vars[key].set(str(row[key]))

    def clear_form(self):
        self.selected_id = None
        defaults = {"course": "MCA", "semester": "1", "marks": "0"}
        for key, var in self.vars.items():
            var.set(defaults.get(key, ""))
        for selected in self.tree.selection():
            self.tree.selection_remove(selected)


if __name__ == "__main__":
    setup_database()
    root = tk.Tk()
    app = StudentManagementApp(root)
    root.mainloop()
